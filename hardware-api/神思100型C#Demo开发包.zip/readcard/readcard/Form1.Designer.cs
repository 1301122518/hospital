﻿namespace readcard
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.newAddress = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.read = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tbnation = new System.Windows.Forms.TextBox();
            this.tbbirth = new System.Windows.Forms.TextBox();
            this.tbsex = new System.Windows.Forms.TextBox();
            this.tbaddress = new System.Windows.Forms.TextBox();
            this.tbsfzh = new System.Windows.Forms.TextBox();
            this.tbqfjg = new System.Windows.Forms.TextBox();
            this.tbbegintime = new System.Windows.Forms.TextBox();
            this.tbendtime = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lborgan = new System.Windows.Forms.Label();
            this.lbidentitycard = new System.Windows.Forms.Label();
            this.lbaddress = new System.Windows.Forms.Label();
            this.lbbirth = new System.Windows.Forms.Label();
            this.lbnation = new System.Windows.Forms.Label();
            this.lbsex = new System.Windows.Forms.Label();
            this.tbname = new System.Windows.Forms.TextBox();
            this.lbname = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // newAddress
            // 
            this.newAddress.Location = new System.Drawing.Point(120, 319);
            this.newAddress.Name = "newAddress";
            this.newAddress.ReadOnly = true;
            this.newAddress.Size = new System.Drawing.Size(263, 21);
            this.newAddress.TabIndex = 49;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 328);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 48;
            this.label1.Text = "最新地址：";
            // 
            // timer1
            // 
            this.timer1.Interval = 200;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(42, 352);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(345, 98);
            this.textBox1.TabIndex = 47;
            // 
            // read
            // 
            this.read.Location = new System.Drawing.Point(96, 471);
            this.read.Name = "read";
            this.read.Size = new System.Drawing.Size(75, 23);
            this.read.TabIndex = 46;
            this.read.Text = "开始读卡";
            this.read.UseVisualStyleBackColor = true;
            this.read.Click += new System.EventHandler(this.read_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(258, 471);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 45;
            this.button1.Text = "清空";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox1.Location = new System.Drawing.Point(281, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 120);
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // tbnation
            // 
            this.tbnation.Location = new System.Drawing.Point(96, 101);
            this.tbnation.Name = "tbnation";
            this.tbnation.ReadOnly = true;
            this.tbnation.Size = new System.Drawing.Size(131, 21);
            this.tbnation.TabIndex = 43;
            // 
            // tbbirth
            // 
            this.tbbirth.Location = new System.Drawing.Point(96, 137);
            this.tbbirth.Name = "tbbirth";
            this.tbbirth.ReadOnly = true;
            this.tbbirth.Size = new System.Drawing.Size(131, 21);
            this.tbbirth.TabIndex = 42;
            // 
            // tbsex
            // 
            this.tbsex.Location = new System.Drawing.Point(96, 65);
            this.tbsex.Name = "tbsex";
            this.tbsex.ReadOnly = true;
            this.tbsex.Size = new System.Drawing.Size(131, 21);
            this.tbsex.TabIndex = 44;
            // 
            // tbaddress
            // 
            this.tbaddress.Location = new System.Drawing.Point(96, 173);
            this.tbaddress.Name = "tbaddress";
            this.tbaddress.ReadOnly = true;
            this.tbaddress.Size = new System.Drawing.Size(291, 21);
            this.tbaddress.TabIndex = 41;
            // 
            // tbsfzh
            // 
            this.tbsfzh.Location = new System.Drawing.Point(134, 211);
            this.tbsfzh.Name = "tbsfzh";
            this.tbsfzh.ReadOnly = true;
            this.tbsfzh.Size = new System.Drawing.Size(253, 21);
            this.tbsfzh.TabIndex = 40;
            // 
            // tbqfjg
            // 
            this.tbqfjg.Location = new System.Drawing.Point(134, 248);
            this.tbqfjg.Name = "tbqfjg";
            this.tbqfjg.ReadOnly = true;
            this.tbqfjg.Size = new System.Drawing.Size(253, 21);
            this.tbqfjg.TabIndex = 39;
            // 
            // tbbegintime
            // 
            this.tbbegintime.Location = new System.Drawing.Point(121, 285);
            this.tbbegintime.Name = "tbbegintime";
            this.tbbegintime.ReadOnly = true;
            this.tbbegintime.Size = new System.Drawing.Size(106, 21);
            this.tbbegintime.TabIndex = 38;
            // 
            // tbendtime
            // 
            this.tbendtime.Location = new System.Drawing.Point(280, 285);
            this.tbendtime.Name = "tbendtime";
            this.tbendtime.ReadOnly = true;
            this.tbendtime.Size = new System.Drawing.Size(106, 21);
            this.tbendtime.TabIndex = 37;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(49, 294);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 36;
            this.label10.Text = "有效期：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(246, 288);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(17, 12);
            this.label8.TabIndex = 35;
            this.label8.Text = "至";
            // 
            // lborgan
            // 
            this.lborgan.AutoSize = true;
            this.lborgan.Location = new System.Drawing.Point(49, 257);
            this.lborgan.Name = "lborgan";
            this.lborgan.Size = new System.Drawing.Size(65, 12);
            this.lborgan.TabIndex = 34;
            this.lborgan.Text = "签发机关：";
            // 
            // lbidentitycard
            // 
            this.lbidentitycard.AutoSize = true;
            this.lbidentitycard.Location = new System.Drawing.Point(49, 220);
            this.lbidentitycard.Name = "lbidentitycard";
            this.lbidentitycard.Size = new System.Drawing.Size(65, 12);
            this.lbidentitycard.TabIndex = 33;
            this.lbidentitycard.Text = "身份证号：";
            // 
            // lbaddress
            // 
            this.lbaddress.AutoSize = true;
            this.lbaddress.Location = new System.Drawing.Point(49, 183);
            this.lbaddress.Name = "lbaddress";
            this.lbaddress.Size = new System.Drawing.Size(41, 12);
            this.lbaddress.TabIndex = 32;
            this.lbaddress.Text = "住址：";
            // 
            // lbbirth
            // 
            this.lbbirth.AutoSize = true;
            this.lbbirth.Location = new System.Drawing.Point(49, 146);
            this.lbbirth.Name = "lbbirth";
            this.lbbirth.Size = new System.Drawing.Size(41, 12);
            this.lbbirth.TabIndex = 31;
            this.lbbirth.Text = "出生：";
            // 
            // lbnation
            // 
            this.lbnation.AutoSize = true;
            this.lbnation.Location = new System.Drawing.Point(49, 109);
            this.lbnation.Name = "lbnation";
            this.lbnation.Size = new System.Drawing.Size(41, 12);
            this.lbnation.TabIndex = 30;
            this.lbnation.Text = "民族：";
            // 
            // lbsex
            // 
            this.lbsex.AutoSize = true;
            this.lbsex.Location = new System.Drawing.Point(49, 72);
            this.lbsex.Name = "lbsex";
            this.lbsex.Size = new System.Drawing.Size(41, 12);
            this.lbsex.TabIndex = 29;
            this.lbsex.Text = "性别：";
            // 
            // tbname
            // 
            this.tbname.Location = new System.Drawing.Point(96, 29);
            this.tbname.Name = "tbname";
            this.tbname.ReadOnly = true;
            this.tbname.Size = new System.Drawing.Size(131, 21);
            this.tbname.TabIndex = 28;
            // 
            // lbname
            // 
            this.lbname.AutoSize = true;
            this.lbname.Location = new System.Drawing.Point(49, 35);
            this.lbname.Name = "lbname";
            this.lbname.Size = new System.Drawing.Size(41, 12);
            this.lbname.TabIndex = 27;
            this.lbname.Text = "姓名：";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(447, 509);
            this.Controls.Add(this.newAddress);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.read);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tbnation);
            this.Controls.Add(this.tbbirth);
            this.Controls.Add(this.tbsex);
            this.Controls.Add(this.tbaddress);
            this.Controls.Add(this.tbsfzh);
            this.Controls.Add(this.tbqfjg);
            this.Controls.Add(this.tbbegintime);
            this.Controls.Add(this.tbendtime);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lborgan);
            this.Controls.Add(this.lbidentitycard);
            this.Controls.Add(this.lbaddress);
            this.Controls.Add(this.lbbirth);
            this.Controls.Add(this.lbnation);
            this.Controls.Add(this.lbsex);
            this.Controls.Add(this.tbname);
            this.Controls.Add(this.lbname);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox newAddress;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button read;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox tbnation;
        private System.Windows.Forms.TextBox tbbirth;
        private System.Windows.Forms.TextBox tbsex;
        private System.Windows.Forms.TextBox tbaddress;
        private System.Windows.Forms.TextBox tbsfzh;
        private System.Windows.Forms.TextBox tbqfjg;
        private System.Windows.Forms.TextBox tbbegintime;
        private System.Windows.Forms.TextBox tbendtime;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lborgan;
        private System.Windows.Forms.Label lbidentitycard;
        private System.Windows.Forms.Label lbaddress;
        private System.Windows.Forms.Label lbbirth;
        private System.Windows.Forms.Label lbnation;
        private System.Windows.Forms.Label lbsex;
        private System.Windows.Forms.TextBox tbname;
        private System.Windows.Forms.Label lbname;
    }
}

