﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using System.Drawing.Imaging;
namespace readcard
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public bool PicBoxLoadPic(PictureBox pictureBox, string picFileName, int picshow)
        {
            bool ret = false;
            try
            {
                if (!File.Exists(picFileName))
                {
                    pictureBox.Image = null;
                    return ret;
                }
                /*
                if (picshow == 1)
                {
                    pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                }
                else 
                {
                    pictureBox.SizeMode = PictureBoxSizeMode.AutoSize;
                }*/
                pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                //这种方式不好，载入文件后一直占有，所以改用流的方式
                //Bitmap myImage = new Bitmap(picFileName);
                //pictureBox.Size = myImage.Size;//new Size(300,400);
                //pictureBox.Image = (Image)myImage;
                //pictureBox.Image = Bitmap.FromFile(picFileName); //这种方式不好，载入文件后一直占有
                using (FileStream fs = new FileStream(picFileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    BinaryReader br = new BinaryReader(fs);
                    MemoryStream ms = new MemoryStream(br.ReadBytes((int)fs.Length));
                    pictureBox.Image = Image.FromStream(ms);
                }
                ret = true;
            }
            catch (Exception ex)
            {
            }
            return ret;
        }


        private void read_Click(object sender, EventArgs e)
        {
            string sMsg = string.Empty;
            if ("开始读卡" == read.Text.Trim())
            {
                read.Text = "停止读卡";
                if (!IDCardReader.InitCom(0, out sMsg))
                {
                    MessageBox.Show(sMsg);
                    read.Text = "开始读卡";
                }
                else
                {
                    timer1.Enabled = true;
                }
            }
            else if ("停止读卡" == read.Text.Trim())
            {
                read.Text = "开始读卡";
                timer1.Enabled = false;
                IDCardReader.CloseCom(0);
            }

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            IDCardReader.CloseCom(0);
        }
        private void ReadCard()
        {
            string sMsg = string.Empty;
            //发布后的运行路劲，发布的是Release版本的
            string sPath = System.Environment.CurrentDirectory.Substring(0, System.Environment.CurrentDirectory.LastIndexOf('\\')); //
            sPath = System.Environment.CurrentDirectory + "\\";
            //未发布的程序运行路劲
#if DEBUG
            sPath = System.Windows.Forms.Application.StartupPath;
#endif
            CardInfo objIDCardInfo = null;
            try
            {
                //读身份证对象
                objIDCardInfo = IDCardReader.ReadCardInfo(0, out sMsg, sPath);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(sMsg);
                throw ex;
            }

            if (null != objIDCardInfo)
            {
                //赋值
                tbsfzh.Text = objIDCardInfo.CardNo;
                tbname.Text = objIDCardInfo.Name;
                tbsex.Text = objIDCardInfo.Sex;
                tbbirth.Text = objIDCardInfo.Birthday;
                tbqfjg.Text = objIDCardInfo.Department;
                tbbegintime.Text = objIDCardInfo.StartDate;
                tbendtime.Text = objIDCardInfo.EndDate;
                tbnation.Text = objIDCardInfo.Nation;
                tbaddress.Text = objIDCardInfo.Address;
                PicBoxLoadPic(pictureBox1, objIDCardInfo.PhotoPath , 0);
                newAddress.Text = objIDCardInfo.AddressEx;

            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            ReadCard();
        }
    }
}
